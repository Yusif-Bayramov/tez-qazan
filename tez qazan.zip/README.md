# tez-qazan
# Creators -  Bayramov Yusif, Ahmadov Kamal
